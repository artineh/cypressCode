
//visit the home page of flora.am
describe('Testing the WishList', () => {
   it('go to the main url"', () => {
     cy.visit('https://www.flora.am/index.php?page=1&page_select=1&prod_count=1&lang=3&%20currency=1&site=1&sort=1');
 
   })

   it('add the first product to favorites', () => {
      cy.get('.row > :nth-child(1) > .product > .product-body > .product-btns > .main-btn').click();
  
    })

    it('check to see if the number in wishlist has changed to 1', () => {
      cy.get('.dropdown > .dropdown-toggle > .header-btns-icon > .qty').contains(1);
      
    })

    it('go to wishlist and delete the product', () => {
      cy.get('.dropdown > .dropdown-toggle > .header-btns-icon').click();
      
      cy.get('.cancel-btn > .fa').click();
      
    })

   
})
